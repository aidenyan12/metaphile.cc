
import React, { useState } from 'react';
import { motion, AnimatePresence } from 'framer-motion';
import { Badge } from '@/components/ui/badge';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { projects, categories, allHashtags } from '@/data/projects.js';

const PortfolioGallery = () => {
  const [activeCategory, setActiveCategory] = useState('All');
  const [activeHashtags, setActiveHashtags] = useState([]);

  const toggleHashtag = (tag) => {
    setActiveHashtags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const filteredProjects = projects.filter(project => {
    const matchesCategory = activeCategory === 'All' || project.category === activeCategory;
    const matchesHashtags = activeHashtags.length === 0 || activeHashtags.every(tag => project.hashtags.includes(tag));
    return matchesCategory && matchesHashtags;
  });

  return (
    <>
      <Helmet>
        <title>Portfolio Gallery - Metaphile</title>
        <meta name="description" content="Explore our curated collection of projects spanning cultural intelligence, education technology, and research data aesthetics." />
      </Helmet>
      
      <div className="min-h-screen bg-background">
        {/* Hero Section */}
        <section className="py-20 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto text-center">
            <motion.h1 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              className="text-5xl md:text-6xl lg:text-7xl font-bold text-foreground mb-6" 
              style={{letterSpacing: '-0.02em'}}
            >
              METAPHILE
            </motion.h1>
            <motion.p 
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ delay: 0.1 }}
              className="text-lg md:text-xl text-muted-foreground max-w-2xl mx-auto leading-relaxed"
            >
              A curated collection of creative work spanning cultural intelligence, education technology, and research data aesthetics.
            </motion.p>
          </div>
        </section>

        {/* Filter Section */}
        <section className="py-8 px-4 sm:px-6 lg:px-8 border-b border-border bg-background/50 backdrop-blur-sm sticky top-16 z-40">
          <div className="max-w-7xl mx-auto flex flex-col gap-8">
            {/* Categories */}
            <div className="flex flex-wrap gap-3 justify-center">
              {categories.map((category) => (
                <button
                  key={category}
                  onClick={() => setActiveCategory(category)}
                  className={`px-6 py-2.5 rounded-full font-medium transition-all duration-200 text-sm md:text-base ${
                    activeCategory === category
                      ? 'bg-primary text-primary-foreground shadow-md scale-105'
                      : 'bg-muted text-muted-foreground hover:bg-muted/80 hover:text-foreground'
                  }`}
                >
                  {category}
                </button>
              ))}
            </div>

            {/* Hashtags */}
            <div className="flex flex-wrap gap-2 justify-center max-w-4xl mx-auto">
              {allHashtags.map(tag => (
                <button
                  key={tag}
                  onClick={() => toggleHashtag(tag)}
                  className={`hashtag ${activeHashtags.includes(tag) ? 'active' : ''}`}
                  aria-label={`Filter by #${tag}`}
                  aria-pressed={activeHashtags.includes(tag)}
                >
                  #{tag}
                </button>
              ))}
            </div>
          </div>
        </section>

        {/* Gallery Grid */}
        <section className="py-16 px-4 sm:px-6 lg:px-8">
          <div className="max-w-7xl mx-auto">
            <AnimatePresence mode="wait">
              <motion.div
                key={`${activeCategory}-${activeHashtags.join(',')}`}
                initial={{ opacity: 0, y: 20 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -20 }}
                transition={{ duration: 0.3 }}
                className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8"
              >
                {filteredProjects.map((project, index) => (
                  <motion.div
                    key={project.id}
                    initial={{ opacity: 0, y: 20 }}
                    animate={{ opacity: 1, y: 0 }}
                    transition={{ duration: 0.4, delay: index * 0.05 }}
                    className="h-full"
                  >
                    <Link 
                      to={`/project/${project.id}`}
                      className="group block h-full bg-card rounded-2xl overflow-hidden shadow-sm border border-border/50 card-hover flex flex-col"
                    >
                      {/* Image */}
                      <div className="aspect-[4/3] overflow-hidden bg-muted shrink-0 relative">
                        <img
                          src={project.image}
                          alt={project.title}
                          className="w-full h-full object-cover transition-transform duration-700 group-hover:scale-105"
                        />
                        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
                      </div>
                      
                      {/* Content */}
                      <div className="p-6 flex flex-col flex-grow">
                        <div className="mb-4">
                          <Badge variant="secondary" className="text-xs font-medium line-clamp-1 bg-muted/50" title={project.category}>
                            {project.category}
                          </Badge>
                        </div>
                        <h3 className="text-xl font-semibold text-foreground mb-3 leading-snug group-hover:text-primary transition-colors">
                          {project.title}
                        </h3>
                        <p className="text-sm text-muted-foreground leading-relaxed mb-6 flex-grow line-clamp-3">
                          {project.description}
                        </p>
                        
                        {/* Hashtags Preview */}
                        <div className="flex flex-wrap gap-2 mt-auto pt-4 border-t border-border/50">
                          {project.hashtags.slice(0, 3).map(tag => (
                            <span key={tag} className="text-xs font-medium text-muted-foreground">
                              #{tag}
                            </span>
                          ))}
                          {project.hashtags.length > 3 && (
                            <span className="text-xs font-medium text-muted-foreground">
                              +{project.hashtags.length - 3} more
                            </span>
                          )}
                        </div>
                      </div>
                    </Link>
                  </motion.div>
                ))}
              </motion.div>
            </AnimatePresence>

            {/* Empty State */}
            {filteredProjects.length === 0 && (
              <motion.div 
                initial={{ opacity: 0 }}
                animate={{ opacity: 1 }}
                className="text-center py-24 bg-muted/30 rounded-2xl border border-border border-dashed mt-8"
              >
                <p className="text-muted-foreground text-lg mb-6">No projects found matching all selected filters.</p>
                <button
                  onClick={() => {
                    setActiveCategory('All');
                    setActiveHashtags([]);
                  }}
                  className="inline-flex items-center justify-center px-6 py-3 rounded-full bg-primary text-primary-foreground font-medium hover:bg-primary/90 transition-colors"
                >
                  Clear all filters
                </button>
              </motion.div>
            )}
          </div>
        </section>
      </div>
    </>
  );
};

export default PortfolioGallery;
