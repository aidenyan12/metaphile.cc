
export const projects = [
  // CULTURAL INTELLIGENCE & DIGITAL TRANSFORMATION
  {
    id: 1,
    title: 'Global Voices Platform',
    category: 'Cultural Intelligence & Digital Transformation',
    description: 'Bridging cultural narratives through interactive digital storytelling',
    image: 'https://images.unsplash.com/photo-1629019324504-2e1fdf96e5e0',
    hashtags: ['culture', 'digital', 'transformation', 'innovation', 'global']
  },
  {
    id: 2,
    title: 'Cross-Cultural Exchange Initiative',
    category: 'Cultural Intelligence & Digital Transformation',
    description: 'Digital infrastructure for international cultural collaboration',
    image: 'https://images.unsplash.com/photo-1651773765931-77ff3d75d393',
    hashtags: ['culture', 'digital', 'transformation', 'innovation', 'global']
  },
  {
    id: 3,
    title: 'Heritage Digitization Project',
    category: 'Cultural Intelligence & Digital Transformation',
    description: 'Preserving cultural artifacts through advanced digital technologies',
    image: 'https://images.unsplash.com/flagged/photo-1564445477052-8a3787406bbf',
    hashtags: ['culture', 'digital', 'transformation', 'innovation', 'global']
  },
  {
    id: 4,
    title: 'Inclusive Digital Ecosystems',
    category: 'Cultural Intelligence & Digital Transformation',
    description: 'Creating accessible platforms for diverse global communities',
    image: 'https://images.unsplash.com/photo-1544006658-5ed4d689eb5e',
    hashtags: ['culture', 'digital', 'transformation', 'innovation', 'global']
  },
  {
    id: 5,
    title: 'Intercultural Communication Hub',
    category: 'Cultural Intelligence & Digital Transformation',
    description: 'Technology-enabled dialogue across cultural boundaries',
    image: 'https://images.unsplash.com/photo-1692976001563-41fa7497d81d',
    hashtags: ['culture', 'digital', 'transformation', 'innovation', 'global']
  },
  
  // EDUCATION TECHNOLOGY & LEARNING DESIGN
  {
    id: 6,
    title: 'Adaptive Learning Ecosystem',
    category: 'Education Technology & Learning Design',
    description: 'Personalized educational pathways powered by intelligent design',
    image: 'https://images.unsplash.com/photo-1679316481049-4f6549df499f',
    hashtags: ['edtech', 'learning', 'design', 'pedagogy', 'interactive']
  },
  {
    id: 7,
    title: 'Interactive Knowledge Visualization',
    category: 'Education Technology & Learning Design',
    description: 'Transforming complex concepts into engaging visual learning experiences',
    image: 'https://images.unsplash.com/photo-1694532409273-b26e2ce266ea',
    hashtags: ['edtech', 'learning', 'design', 'pedagogy', 'interactive']
  },
  {
    id: 8,
    title: 'Collaborative Learning Platform',
    category: 'Education Technology & Learning Design',
    description: 'Fostering peer-to-peer education through innovative digital design',
    image: 'https://images.unsplash.com/photo-1695133139074-d0ab15d6d7da',
    hashtags: ['edtech', 'learning', 'design', 'pedagogy', 'interactive']
  },
  {
    id: 9,
    title: 'Gamified Educational Experience',
    category: 'Education Technology & Learning Design',
    description: 'Engaging learners through interactive game-based pedagogy',
    image: 'https://images.unsplash.com/photo-1507131679781-70be42a343e7',
    hashtags: ['edtech', 'learning', 'design', 'pedagogy', 'interactive']
  },
  {
    id: 10,
    title: 'Immersive Learning Environments',
    category: 'Education Technology & Learning Design',
    description: 'Next-generation educational spaces with interactive design principles',
    image: 'https://images.unsplash.com/photo-1576870397449-6ef1af18beb4',
    hashtags: ['edtech', 'learning', 'design', 'pedagogy', 'interactive']
  },

  // RESEARCH, ARCHIVES & DATA AESTHETICS
  {
    id: 11,
    title: 'Data Visualization Archive',
    category: 'Research, Archives & Data Aesthetics',
    description: 'Aesthetic representation of complex research datasets',
    image: 'https://images.unsplash.com/photo-1596774419796-0318e0ab4ba1',
    hashtags: ['research', 'data', 'archives', 'visualization', 'aesthetics']
  },
  {
    id: 12,
    title: 'Digital Archives Repository',
    category: 'Research, Archives & Data Aesthetics',
    description: 'Curated collection of historical research materials with elegant interface',
    image: 'https://images.unsplash.com/photo-1675023112817-52b789fd2ef0',
    hashtags: ['research', 'data', 'archives', 'visualization', 'aesthetics']
  },
  {
    id: 13,
    title: 'Research Data Storytelling',
    category: 'Research, Archives & Data Aesthetics',
    description: 'Transforming academic findings into compelling visual narratives',
    image: 'https://images.unsplash.com/photo-1516383274235-5f42d6c6426d',
    hashtags: ['research', 'data', 'archives', 'visualization', 'aesthetics']
  },
  {
    id: 14,
    title: 'Scholarly Knowledge Graph',
    category: 'Research, Archives & Data Aesthetics',
    description: 'Interactive mapping of research connections and academic relationships',
    image: 'https://images.unsplash.com/photo-1686061593213-98dad7c599b9',
    hashtags: ['research', 'data', 'archives', 'visualization', 'aesthetics']
  },
  {
    id: 15,
    title: 'Historical Data Aesthetics',
    category: 'Research, Archives & Data Aesthetics',
    description: 'Beautiful visualization of archival research and temporal patterns',
    image: 'https://images.unsplash.com/photo-1548230445-ca4ebd9755a8',
    hashtags: ['research', 'data', 'archives', 'visualization', 'aesthetics']
  }
];

export const categories = [
  'All', 
  'Cultural Intelligence & Digital Transformation', 
  'Education Technology & Learning Design', 
  'Research, Archives & Data Aesthetics'
];

export const allHashtags = Array.from(new Set(projects.flatMap(p => p.hashtags))).sort();
