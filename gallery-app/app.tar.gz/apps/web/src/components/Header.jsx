
import React from 'react';
import { Link } from 'react-router-dom';
import { Menu } from 'lucide-react';
import { Sheet, SheetContent, SheetTrigger, SheetTitle } from '@/components/ui/sheet';
import { Button } from '@/components/ui/button';

const Header = () => {
  return (
    <header className="sticky top-0 z-50 w-full border-b border-border/40 bg-background/80 backdrop-blur-md">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between">
        <Link to="/" className="flex items-center gap-2 transition-opacity hover:opacity-80">
          <span className="font-sora text-xl font-bold tracking-tight text-foreground">
            METAPHILE
          </span>
        </Link>

        {/* Desktop Nav */}
        <nav className="hidden md:flex items-center gap-6">
          <Link to="/" className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors">
            Gallery
          </Link>
          <a 
            href="https://www.metaphile.io" 
            target="_blank" 
            rel="noopener noreferrer"
            className="text-sm font-medium text-muted-foreground hover:text-foreground transition-colors"
          >
            About Metaphile
          </a>
          <Button asChild variant="default" className="rounded-full px-6">
            <a href="https://www.metaphile.io" target="_blank" rel="noopener noreferrer">
              Visit Website
            </a>
          </Button>
        </nav>

        {/* Mobile Nav */}
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="ghost" size="icon" aria-label="Menu">
                <Menu className="h-5 w-5" />
              </Button>
            </SheetTrigger>
            <SheetContent side="right" className="w-[300px] sm:w-[400px]">
              <SheetTitle className="font-sora text-left mb-8">Navigation</SheetTitle>
              <nav className="flex flex-col gap-4">
                <Link to="/" className="text-lg font-medium text-foreground hover:text-primary transition-colors">
                  Gallery
                </Link>
                <a 
                  href="https://www.metaphile.io" 
                  target="_blank" 
                  rel="noopener noreferrer"
                  className="text-lg font-medium text-foreground hover:text-primary transition-colors"
                >
                  About Metaphile
                </a>
                <div className="pt-4 mt-4 border-t border-border">
                  <Button asChild className="w-full rounded-full">
                    <a href="https://www.metaphile.io" target="_blank" rel="noopener noreferrer">
                      Visit Website
                    </a>
                  </Button>
                </div>
              </nav>
            </SheetContent>
          </Sheet>
        </div>
      </div>
    </header>
  );
};

export default Header;
