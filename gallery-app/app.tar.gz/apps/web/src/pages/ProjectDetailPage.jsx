
import React, { useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowLeft } from 'lucide-react';
import { Helmet } from 'react-helmet';
import { Badge } from '@/components/ui/badge';
import { Button } from '@/components/ui/button';
import { projects } from '@/data/projects.js';

const ProjectDetailPage = () => {
  const { projectId } = useParams();
  const navigate = useNavigate();
  
  const project = projects.find(p => p.id === parseInt(projectId));

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [projectId]);

  if (!project) {
    return (
      <div className="min-h-[60vh] flex flex-col items-center justify-center px-4">
        <h1 className="text-3xl font-bold mb-4">Project Not Found</h1>
        <p className="text-muted-foreground mb-8">The project you're looking for doesn't exist or has been removed.</p>
        <Button onClick={() => navigate('/')}>Return to Gallery</Button>
      </div>
    );
  }

  return (
    <>
      <Helmet>
        <title>{`${project.title} | Metaphile Portfolio`}</title>
        <meta name="description" content={project.description} />
      </Helmet>

      <article className="min-h-screen bg-background pb-24">
        {/* Hero Image */}
        <div className="w-full h-[40vh] md:h-[60vh] lg:h-[70vh] relative bg-muted overflow-hidden">
          <motion.img 
            initial={{ scale: 1.05, opacity: 0 }}
            animate={{ scale: 1, opacity: 1 }}
            transition={{ duration: 0.8, ease: "easeOut" }}
            src={project.image} 
            alt={project.title}
            className="w-full h-full object-cover"
          />
          <div className="absolute inset-0 bg-gradient-to-t from-background/80 via-background/20 to-transparent" />
        </div>

        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 -mt-20 relative z-10">
          <motion.div 
            initial={{ y: 40, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ duration: 0.6, delay: 0.2 }}
            className="bg-card rounded-2xl shadow-xl p-8 md:p-12 border border-border/50"
          >
            <Link 
              to="/" 
              className="inline-flex items-center text-sm font-medium text-muted-foreground hover:text-foreground transition-colors mb-8 group"
            >
              <ArrowLeft className="w-4 h-4 mr-2 transition-transform group-hover:-translate-x-1" />
              Back to Gallery
            </Link>

            <div className="mb-6">
              <Badge variant="secondary" className="text-sm px-3 py-1 font-medium">
                {project.category}
              </Badge>
            </div>

            <h1 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-6 leading-tight">
              {project.title}
            </h1>

            <p className="text-lg md:text-xl text-muted-foreground leading-relaxed mb-10">
              {project.description}
            </p>

            <div className="pt-8 border-t border-border">
              <h3 className="text-sm font-semibold text-foreground uppercase tracking-wider mb-4">
                Project Tags
              </h3>
              <div className="flex flex-wrap gap-2">
                {project.hashtags.map(tag => (
                  <span key={tag} className="hashtag cursor-default hover:bg-[hsl(var(--hashtag-bg))] hover:text-[hsl(var(--hashtag-text))]">
                    #{tag}
                  </span>
                ))}
              </div>
            </div>
          </motion.div>
        </div>
      </article>
    </>
  );
};

export default ProjectDetailPage;
